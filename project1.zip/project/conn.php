<?php
// Database configuration
$host = 'localhost';        // Usually 'localhost'
$dbname = 'comm';      // Your database name
$username = 'root';         // Your database username
$password = '';             // Your database password

try {
    // Create a new PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);

    // Set PDO error mode to exception for better error handling
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Optional: Disable emulated prepared statements for security
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

    // Connection successful (you can uncomment the line below for testing)
    // echo "Connected to the database successfully.";

} catch (PDOException $e) {
    // Handle connection error
    die("Database connection failed: " . $e->getMessage());
}
?>
