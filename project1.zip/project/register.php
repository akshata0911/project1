<?php
include 'conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
    $name     = $_POST["name"];
    $username = $_POST["username"];
    $email    = $_POST["email"];
    $password = $_POST["password"];
    $confirm  = $_POST["confirm"];

    if ($password !== $confirm) {
        die("Passwords do not match.");
    }

    // ✅ Properly hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // ✅ Insert into table (make sure columns match)
    $stmt = $conn->prepare("INSERT INTO users (name, username, email, phone, password, confirm) VALUES (?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    // ✅ Store hashed password in both password and confirm columns
    $stmt->bind_param("ssssss", $name, $username, $email, $hashedPassword, $hashedPassword);

    if ($stmt->execute()) {
        echo "<script>alert('Registration successful!'); window.location.href='log.html';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>