<?php
session_start();
include 'conn.php';

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["submit"])) {
    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    $stmt = $conn->prepare("SELECT name, password FROM users WHERE email = ?");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($name, $hashedPassword);
        $stmt->fetch();

      if (password_verify($password, $hashedPassword)) {
            $_SESSION["user_name"] = $name;
            header("Location: index.php");
            exit;
        } else {
            echo "<script>alert('❌ Invalid password.'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('❌ User not found.'); window.history.back();</script>";
    }
}
?>